# 全球科技 / AI / 商业资讯可信信息源整合清单（含可靠度评分）

> **整合说明**：本清单基于两份原始信源清单（《全球科技、AI 与商业资讯可信信息源清单》《全球科技 / AI / 商业资讯信息源精选清单》）整合去重而成，覆盖独立新闻网站、AI 垂直媒体、商业财经媒体、研究机构、社区论坛、Newsletter、播客、YouTube 频道与 X(Twitter) 博主等。
> 
> **可靠度评分（Reliability，1–5 分）说明**：
> 
> - ⭐⭐⭐⭐⭐ **5 分**：通讯社级 / 顶级期刊 / 权威研究机构
> - ⭐⭐⭐⭐ **4 分**：公认深度优质媒体或作者
> - ⭐⭐⭐ **3 分**：主流可靠媒体或活跃创作者
> - ⭐⭐ **2 分**：聚合站 / 社区 / 快讯型，需结合多源
> - ⭐ **1 分**：信噪比一般、立场较强或质量分散，需自行筛选（
> 
> 📅 整合时间：2026 年 5 月

---

## 一、综合科技与互联网媒体

### 1.1 主流综合科技媒体（英文）

| 名称 | 链接 | 角色 | 内容特点 | 更新频率 | 可靠度 |
|-|-|-|-|-|-|
| The Verge | [theverge.com](https://www.theverge.com) | ⚡🔭 | Vox Media 旗下，覆盖消费电子、平台、政策、文化，文笔好、视觉精致 | 每日多更 | ⭐⭐⭐ |
| TechCrunch | [techcrunch.com](https://techcrunch.com) | ⚡💰 | 创业、融资、产品发布的事实型快讯，硅谷生态报道密集 | 每日多更 | ⭐⭐⭐ |
| Wired | [wired.com](https://www.wired.com) | 📊🔭 | 长报道见长，技术 × 社会 × 文化交叉视角 | 每日 | ⭐⭐⭐⭐ |
| Ars Technica | [arstechnica.com](https://arstechnica.com) | 📊 | 工程向，对技术细节诚实，安全/操作系统/硬件评测口碑好 | 每日 | ⭐⭐⭐⭐ |
| MIT Technology Review | [technologyreview.com](https://www.technologyreview.com) | 📊📚 | MIT 旗下，AI、生物、能源、气候等前沿议题严肃报道 | 每日 | ⭐⭐⭐⭐⭐ |
| IEEE Spectrum | [spectrum.ieee.org](https://spectrum.ieee.org) | 📊📚 | IEEE 官方，硬科技、半导体、机器人、通信 | 每日 | ⭐⭐⭐⭐⭐ |
| Engadget | [engadget.com](https://www.engadget.com) | ⚡ | 消费电子和产品发布快讯 | 每日 | ⭐⭐ |
| Gizmodo | [gizmodo.com](https://gizmodo.com) | ⚡🔭 | 科技 + 流行文化，调性轻松 | 每日 | ⭐⭐ |
| The Information | [theinformation.com](https://www.theinformation.com) | 📊🔭 | 付费深度，独家信源密集，硅谷大公司、AI、半导体内幕 | 每日 | ⭐⭐⭐⭐⭐ |
| Bloomberg Technology | [bloomberg.com/technology](https://www.bloomberg.com/technology) | ⚡📊 | 金融视角看科技，财报、并购、监管的权威信源 | 每日多更 | ⭐⭐⭐⭐⭐ |
| Reuters Technology | [reuters.com/technology](https://www.reuters.com/technology) | ⚡ | 通讯社级别事实快讯，信源严谨 | 每日多更 | ⭐⭐⭐⭐⭐ |
| Financial Times Tech | [ft.com/technology](https://www.ft.com/technology) | 📊 | 欧洲视角，监管、产业政策、跨国公司报道扎实 | 每日 | ⭐⭐⭐⭐⭐ |
| The New York Times Tech | [nytimes.com/section/technology](https://www.nytimes.com/section/technology) | 📊 | 高质量长报道，调查报道见长 | 每日 | ⭐⭐⭐⭐⭐ |
| The Wall Street Journal Tech | [wsj.com/news/technology](https://www.wsj.com/news/technology) | 📊💰 | 商业视角的科技报道，独家与并购报道强 | 每日 | ⭐⭐⭐⭐⭐ |
| Axios Tech | [axios.com/technology](https://www.axios.com/technology) | ⚡ | "Smart Brevity" 风格，要点式快讯 | 每日多次 | ⭐⭐⭐ |
| Semafor Tech | [semafor.com/tech](https://www.semafor.com/vertical/tech) | 🔭 | 多视角呈现"事实/分析/反方观点"分层；Reed Albergotti 等资深记者主笔 | 每日 | ⭐⭐⭐⭐ |
| Rest of World | [restofworld.org](https://restofworld.org) | 🔭📊 | 专门报道硅谷之外（拉美/非洲/东南亚/东欧）的科技世界 | 每周多更 | ⭐⭐⭐⭐ |
| 404 Media | [404media.co](https://www.404media.co) | 📊 | 前 Vice/Motherboard 团队，调查向科技报道，平台滥用、AI 黑产 | 每周多更 | ⭐⭐⭐⭐ |
| Politico Tech (含原 Protocol) | [politico.com/tech](https://www.politico.com/tech) | 🔭 | 政策 + 科技交叉，DC 视角 | 每日 | ⭐⭐⭐⭐ |
| The Economist – Science & Tech | [economist.com/science-and-technology](https://www.economist.com/science-and-technology) | 📊 | 一周一刊式深度，结构感强 | 周更 | ⭐⭐⭐⭐⭐ |
| The Atlantic – Technology | [theatlantic.com/technology](https://www.theatlantic.com/technology) | 📊 | 思想性强的科技长文，社会人文视角 | 每周 | ⭐⭐⭐⭐ |
| The Guardian Technology | [theguardian.com/technology](https://www.theguardian.com/technology) | 🔭 | 英国/欧洲视角，监管与社会议题敏感 | 每日 | ⭐⭐⭐⭐ |
| Nikkei Asia – Tech | [asia.nikkei.com/Business/Technology](https://asia.nikkei.com/Business/Technology) | 📊 | 亚洲产业链、半导体、日韩台报道权威 | 每日 | ⭐⭐⭐⭐⭐ |
| South China Morning Post – Tech | [scmp.com/tech](https://www.scmp.com/tech) | 🔭 | 中国科技动向的英文权威信源之一 | 每日 | ⭐⭐⭐⭐ |

### 1.2 工程 / 开发者向媒体

| 名称 | 链接 | 内容特点 | 更新频率 | 可靠度 |
|-|-|-|-|-|
| InfoQ | [infoq.com](https://www.infoq.com) | 软件架构、云原生、ML 工程化的资讯与长文 | 每日 | ⭐⭐⭐⭐ |
| The New Stack | [thenewstack.io](https://thenewstack.io) | 云原生、DevOps、AI 工程化报道 | 每日 | ⭐⭐⭐⭐ |
| The Pragmatic Engineer (Gergely Orosz) | [newsletter.pragmaticengineer.com](https://newsletter.pragmaticengineer.com) | 大厂工程实践、薪酬、组织、求职生态 | 周更 | ⭐⭐⭐⭐ |
| LeadDev | [leaddev.com](https://leaddev.com) | 工程领导力、组织管理 | 每周多更 | ⭐⭐⭐⭐ |
| Hacker Noon | [hackernoon.com](https://hackernoon.com) | 工程师社区博客平台，质量参差但有金子 | 每日 | ⭐⭐ |
| ACM Communications | [cacm.acm.org](https://cacm.acm.org) | ACM 学术与产业评论，硬核 | 月更 | ⭐⭐⭐⭐⭐ |
| Stack Overflow Blog | [stackoverflow.blog](https://stackoverflow.blog) | 工程实践、行业调查、年度开发者调研报告 | 不定期 | ⭐⭐⭐⭐ |

### 1.3 头部公司工程 / 研究博客

| 名称 | 链接 | 可靠度 |
|-|-|-|
| Google Research | [research.google](https://research.google) | ⭐⭐⭐⭐⭐ |
| Google DeepMind Blog | [deepmind.google/discover/blog](https://deepmind.google/discover/blog/) | ⭐⭐⭐⭐⭐ |
| OpenAI Blog | [openai.com/blog](https://openai.com/blog) | ⭐⭐⭐⭐⭐ |
| Anthropic News | [anthropic.com/news](https://www.anthropic.com/news) | ⭐⭐⭐⭐⭐ |
| Meta AI | [ai.meta.com/blog](https://ai.meta.com/blog) | ⭐⭐⭐⭐⭐ |
| Microsoft Research | [microsoft.com/research/blog](https://www.microsoft.com/en-us/research/blog) | ⭐⭐⭐⭐⭐ |
| Apple Machine Learning Research | [machinelearning.apple.com](https://machinelearning.apple.com) | ⭐⭐⭐⭐⭐ |
| NVIDIA Developer / Research | [developer.nvidia.com/blog](https://developer.nvidia.com/blog) | ⭐⭐⭐⭐⭐ |
| Cloudflare Blog | [blog.cloudflare.com](https://blog.cloudflare.com) | ⭐⭐⭐⭐ |
| Stripe Engineering | [stripe.com/blog/engineering](https://stripe.com/blog/engineering) | ⭐⭐⭐⭐ |
| Netflix Tech Blog | [netflixtechblog.com](https://netflixtechblog.com) | ⭐⭐⭐⭐ |
| Uber Engineering | [uber.com/blog/engineering](https://www.uber.com/en-US/blog/engineering/) | ⭐⭐⭐⭐ |
| Figma Engineering | [figma.com/blog/engineering](https://www.figma.com/blog/section/engineering/) | ⭐⭐⭐⭐ |
| Hugging Face Blog | [huggingface.co/blog](https://huggingface.co/blog) | ⭐⭐⭐⭐ |
| LangChain Blog | [blog.langchain.dev](https://blog.langchain.dev) | ⭐⭐⭐ |

---

## 二、AI 垂直媒体与研究博客

### 2.1 AI 行业媒体与深度分析

| 名称 | 链接 | 角色 | 内容特点 | 更新频率 | 可靠度 |
|-|-|-|-|-|-|
| Import AI (Jack Clark / Anthropic) | [importai.substack.com](https://importai.substack.com) | 📊🔭 | 学术 + 政策 + 产业三视角，信号密度极高 | 周更 | ⭐⭐⭐⭐⭐ |
| The Batch (DeepLearning.AI / Andrew Ng) | [deeplearning.ai/the-batch](https://www.deeplearning.ai/the-batch/) | 🔭 | 吴恩达团队整理的一周 AI 要闻，新手友好 | 周更 | ⭐⭐⭐⭐ |
| Last Week in AI | [lastweekin.ai](https://lastweekin.ai) | 🔭 | 每周 AI 要点，Stanford 团队维护 | 周更 | ⭐⭐⭐⭐ |
| The Algorithmic Bridge (Alberto Romero) | [thealgorithmicbridge.com](https://www.thealgorithmicbridge.com) | 📊 | 把 AI 学术圈的争论翻译成易读长文 | 周更多次 | ⭐⭐⭐⭐ |
| AI Snake Oil (Arvind Narayanan & Sayash Kapoor) | [aisnakeoil.com](https://www.aisnakeoil.com) | 📊 | Princeton 学者，专门祛魅 AI 炒作 | 周更 | ⭐⭐⭐⭐⭐ |
| Marginal Revolution (Tyler Cowen) | [marginalrevolution.com](https://marginalrevolution.com) | 📊 | 经济学视角，AI/科技/经济交叉 | 每日 | ⭐⭐⭐⭐ |
| Stratechery (Ben Thompson) | [stratechery.com](https://stratechery.com) | 📊💰 | 付费订阅，"Aggregation Theory" 框架；AI 商业化分析最系统 | 周 4–5 | ⭐⭐⭐⭐⭐ |
| Platformer (Casey Newton) | [platformer.news](https://www.platformer.news) | 📊🔭 | 平台公司、内容审核、AI 政策，独家信源密集 | 周更多次 | ⭐⭐⭐⭐⭐ |
| VentureBeat — AI | [venturebeat.com/ai](https://venturebeat.com/category/ai/) | 🔭 | 聚焦企业级 AI 与机器学习应用 | 每日 | ⭐⭐⭐ |
| Garbage Day (Ryan Broderick) | [garbageday.email](https://www.garbageday.email) | 🔭 | 互联网文化与平台动态，犀利且接地气 | 周更多次 | ⭐⭐⭐⭐ |
| Bensbites | [news.bensbites.com](https://news.bensbites.com) | ⚡ | AI 新闻聚合，每日精选链接 | 每日 | ⭐⭐⭐ |
| The Rundown AI | [therundown.ai](https://www.therundown.ai) | ⚡ | 面向大众的日报型 AI Newsletter | 每日 | ⭐⭐ |
| TLDR AI | [tldr.tech/ai](https://tldr.tech/ai) | ⚡ | 5 分钟读完的 AI 速览 | 每日 | ⭐⭐ |
| AlphaSignal | [alphasignal.ai](https://alphasignal.ai) | ⚡ | 偏工程/研究的 AI 周报 | 周更 | ⭐⭐⭐ |
| Latent Space (swyx & Alessio) | [latent.space](https://www.latent.space) | 🎙📊 | AI 工程师文化，播客 + 文章 | 周更 | ⭐⭐⭐⭐ |
| Interconnects (Nathan Lambert) | [interconnects.ai](https://www.interconnects.ai) | 📊 | 专注 RLHF、开源模型与 AI 训练方法 | 周更 | ⭐⭐⭐⭐⭐ |
| The Gradient | [thegradient.pub](https://thegradient.pub) | 📚 | Stanford AI Lab 学生发起，长文质量高 | 月更 | ⭐⭐⭐⭐⭐ |
| Distill (已停更但经典) | [distill.pub](https://distill.pub) | 📚 | 可视化解释 ML，质量极高 | 不更新 | ⭐⭐⭐⭐⭐ |
| Ahead of AI (Sebastian Raschka) | [magazine.sebastianraschka.com](https://magazine.sebastianraschka.com) | 📊📚 | 论文与训练技巧解读，工程实操向 | 月更 | ⭐⭐⭐⭐⭐ |
| Lil'Log (Lilian Weng) | [lilianweng.github.io](https://lilianweng.github.io) | 📚 | OpenAI 研究者的硬核技术博客 | 不定期 | ⭐⭐⭐⭐⭐ |
| Eugene Yan | [eugeneyan.com](https://eugeneyan.com) | 📊 | ML 系统、LLM 应用工程化实战 | 月更 | ⭐⭐⭐⭐ |
| Chip Huyen | [huyenchip.com](https://huyenchip.com) | 📊 | LLM 系统设计、MLOps | 月更 | ⭐⭐⭐⭐⭐ |
| Simon Willison's Weblog | [simonwillison.net](https://simonwillison.net) | 📊 | 几乎每天追 LLM 动态，工程实操记录细 | 高频 | ⭐⭐⭐⭐⭐ |
| Andrej Karpathy – Personal Blog | [karpathy.github.io](https://karpathy.github.io) | 📊 | 顶级研究者随笔与系列教程 | 偶发 | ⭐⭐⭐⭐⭐ |
| AI Supremacy (Michael Spencer) | [aisupremacy.substack.com](https://aisupremacy.substack.com) | 🔭 | 综合性 AI 趋势观察 | 高频 | ⭐⭐⭐ |
| One Useful Thing (Ethan Mollick) | [oneusefulthing.org](https://www.oneusefulthing.org) | 📊 | 沃顿教授，把 LLM 在工作流中的应用讲清楚 | 周更 | ⭐⭐⭐⭐ |

### 2.2 学术与论文跟踪

| 名称 | 链接 | 内容特点 | 可靠度 |
|-|-|-|-|
| arXiv – cs.CL / cs.LG / cs.AI | [arxiv.org/list/cs.CL/recent](https://arxiv.org/list/cs.CL/recent) | AI 论文一手 | ⭐⭐⭐⭐⭐ |
| Papers with Code | [paperswithcode.com](https://paperswithcode.com) | 论文 + 代码 + benchmark | ⭐⭐⭐⭐⭐ |
| Hugging Face Daily Papers | [huggingface.co/papers](https://huggingface.co/papers) | 每日精选 AI 论文，社区讨论 | ⭐⭐⭐⭐ |
| OpenReview | [openreview.net](https://openreview.net) | NeurIPS/ICLR/ICML 论文公开评审 | ⭐⭐⭐⭐⭐ |
| OpenAI Research | [openai.com/research](https://openai.com/research) | 论文与系统卡 | ⭐⭐⭐⭐⭐ |
| Anthropic Research | [anthropic.com/research](https://www.anthropic.com/research) | 对齐与可解释性论文 | ⭐⭐⭐⭐⭐ |
| DeepMind Research | [deepmind.google/research/publications](https://deepmind.google/research/publications/) | 论文页 | ⭐⭐⭐⭐⭐ |
| Meta FAIR | [ai.meta.com/research](https://ai.meta.com/research/) | FAIR 研究 | ⭐⭐⭐⭐⭐ |

---

## 三、商业、财经与产业媒体

### 3.1 主流财经媒体

| 名称 | 链接 | 角色 | 内容特点 | 更新频率 | 可靠度 |
|-|-|-|-|-|-|
| The Wall Street Journal | [wsj.com](https://www.wsj.com) | ⚡📊 | 美国商业报道权威，独家、并购、监管 | 每日多更 | ⭐⭐⭐⭐⭐ |
| Financial Times | [ft.com](https://www.ft.com) | 📊 | 全球宏观、金融、企业战略，欧洲视角 | 每日 | ⭐⭐⭐⭐⭐ |
| Bloomberg | [bloomberg.com](https://www.bloomberg.com) | ⚡📊 | 实时市场、公司情报，专业终端衍生内容 | 全天 | ⭐⭐⭐⭐⭐ |
| The Economist | [economist.com](https://www.economist.com) | 📊 | 一周一刊，议题选择与结构性分析顶级 | 周更 | ⭐⭐⭐⭐⭐ |
| Reuters Business | [reuters.com/business](https://www.reuters.com/business/) | ⚡ | 通讯社级别商业新闻底稿 | 全天 | ⭐⭐⭐⭐⭐ |
| Forbes | [forbes.com](https://www.forbes.com) | 🔭💰 | 财富榜、人物特稿，质量分散 | 每日 | ⭐⭐⭐ |
| Fortune | [fortune.com](https://fortune.com) | 🔭 | 大公司管理与战略，Fortune 500 体系 | 每日 | ⭐⭐⭐⭐ |
| Business Insider | [businessinsider.com](https://www.businessinsider.com) | ⚡🔭 | 综合商业快讯，职场和创投题材多 | 每日 | ⭐⭐⭐ |
| Quartz | [qz.com](https://qz.com) | 🔭 | 全球化视角商业报道 | 每日 | ⭐⭐⭐ |
| CNBC | [cnbc.com](https://www.cnbc.com) | ⚡ | 美国二级市场快讯主力 | 全天 | ⭐⭐⭐⭐ |
| MarketWatch | [marketwatch.com](https://www.marketwatch.com) | ⚡ | 二级市场新闻和数据 | 全天 | ⭐⭐⭐ |
| Barron's | [barrons.com](https://www.barrons.com) | 📊 | 投研周刊型，长期持有视角 | 周更 | ⭐⭐⭐⭐ |
| Nikkei Asia | [asia.nikkei.com](https://asia.nikkei.com) | 📊 | 亚太商业、产业链权威 | 每日 | ⭐⭐⭐⭐⭐ |
| Caixin Global | [caixinglobal.com](https://www.caixinglobal.com) | 📊 | 财新英文版，中国视角下的商业与政策 | 每日 | ⭐⭐⭐⭐⭐ |

### 3.2 商业 × 科技交叉与深度

| 名称 | 链接 | 角色 | 内容特点 | 更新频率 | 可靠度 |
|-|-|-|-|-|-|
| Sharp Tech | [sharptech.fm](https://sharptech.fm) | 🎙 | Ben Thompson + Andrew Sharp 播客 | 周更 | ⭐⭐⭐⭐ |
| Dithering | [dithering.fm](https://dithering.fm) | 🎙 | Ben Thompson + John Gruber，15 分钟科技播客 | 周 2 | ⭐⭐⭐⭐ |
| The Diff (Byrne Hobart) | [thediff.co](https://www.thediff.co) | 📊💰 | 金融 + 科技交叉的高密度长文 | 周 5 | ⭐⭐⭐⭐⭐ |
| Capital Gains (Byrne Hobart) | [capitalgains.thediff.co](https://capitalgains.thediff.co) | 📊 | 金融术语解读 | 周更 | ⭐⭐⭐⭐ |
| Net Interest (Marc Rubinstein) | [netinterest.substack.com](https://www.netinterest.substack.com) | 📊💰 | 金融行业深度解读 | 周更 | ⭐⭐⭐⭐⭐ |
| Money Stuff (Matt Levine, Bloomberg) | [bloomberg.com/.../matt-levine](https://www.bloomberg.com/opinion/authors/ARbTQlRLRjE/matthew-s-levine) | 📊 | 金融市场最有趣的专栏，幽默且专业 | 工作日 | ⭐⭐⭐⭐⭐ |
| Not Boring (Packy McCormick) | [notboring.co](https://www.notboring.co) | 💰🔭 | 商业战略深度长文，风格活泼 | 周更 | ⭐⭐⭐⭐ |
| Every (Dan Shipper 等) | [every.to](https://every.to) | 📊 | AI、生产力、媒体题材的多笔者订阅平台 | 每日多更 | ⭐⭐⭐⭐ |
| The Generalist (Mario Gabriele) | [generalist.com](https://www.generalist.com) | 💰 | 创业公司与 VC 深度长文 | 周更 | ⭐⭐⭐⭐ |
| Big Technology (Alex Kantrowitz) | [bigtechnology.com](https://www.bigtechnology.com) | 🔭🎙 | 大公司深度 + 高质量访谈 | 周更 | ⭐⭐⭐⭐ |
| Newcomer (Eric Newcomer) | [newcomer.co](https://www.newcomer.co) | 💰 | 硅谷创投独家与活动 | 周更多次 | ⭐⭐⭐⭐ |
| Lenny's Newsletter | [lennysnewsletter.com](https://www.lennysnewsletter.com) | 📊 | 前 Airbnb PM，PM 领域影响力最大的 Newsletter 之一 | 周更 | ⭐⭐⭐⭐ |
| Morning Brew | [morningbrew.com](https://www.morningbrew.com) | ⚡ | 风格年轻化的商业财经日报 | 每日 | ⭐⭐⭐ |
| Benedict Evans Newsletter | [ben-evans.com/newsletter](https://www.ben-evans.com/newsletter) | 📊 | 前 a16z 合伙人，数据 + 图表勾勒科技趋势 | 周更 | ⭐⭐⭐⭐⭐ |
| Exponential View (Azeem Azhar) | [exponentialview.co](https://www.exponentialview.co) | 📊 | 关注指数级技术对社会的长期影响 | 周更 | ⭐⭐⭐⭐ |
| Sinocism (Bill Bishop) | [sinocism.com](https://sinocism.com) | 📊 | 中国政经与科技产业的英文 Newsletter | 每日 | ⭐⭐⭐⭐⭐ |
| The Pomp Letter (Anthony Pompliano) | [pomp.substack.com](https://pomp.substack.com) | 💰 | 加密 + 宏观，需筛选信号 | 每日 | ⭐ |

### 3.3 风险投资 / 创投生态

| 名称 | 链接 | 内容特点 | 更新频率 | 可靠度 |
|-|-|-|-|-|
| a16z – Future / Big Ideas | [a16z.com/news-content](https://a16z.com/news-content/) | a16z 投资人撰写的趋势 / 论文 | 不定期 | ⭐⭐⭐⭐ |
| Sequoia – Perspectives | [sequoiacap.com/perspectives](https://www.sequoiacap.com/perspectives/) | 红杉系战略文章 | 月更 | ⭐⭐⭐⭐ |
| USV Writing | [usv.com/writing](https://www.usv.com/writing/) | USV 思考 | 不定期 | ⭐⭐⭐⭐ |
| Greylock – Greymatter | [greylock.com/greymatter](https://greylock.com/greymatter/) | Greylock 思考 | 不定期 | ⭐⭐⭐⭐ |
| Fred Wilson – AVC | [avc.com](https://avc.com) | USV 创始人长期博客 | 每日 | ⭐⭐⭐⭐ |
| Both Sides of the Table (Mark Suster) | [bothsidesofthetable.com](https://bothsidesofthetable.com) | VC 视角创业建议 | 月更 | ⭐⭐⭐⭐ |
| First Round Review | [review.firstround.com](https://review.firstround.com) | 创业方法论长文 | 月更 | ⭐⭐⭐⭐ |
| Y Combinator Library | [ycombinator.com/library](https://www.ycombinator.com/library/) | YC 经典内容沉淀 | 不定期 | ⭐⭐⭐⭐⭐ |
| CB Insights Research | [cbinsights.com/research](https://www.cbinsights.com/research) | 独角兽、AI 100、Fintech 100 等行业地图 | 每周 | ⭐⭐⭐⭐⭐ |
| PitchBook News | [pitchbook.com/news](https://pitchbook.com/news) | 一级市场数据库新闻 | 每日 | ⭐⭐⭐⭐⭐ |
| Crunchbase News | [news.crunchbase.com](https://news.crunchbase.com) | 融资快讯 | 每日 | ⭐⭐⭐⭐ |
| Term Sheet (Fortune) | [fortune.com/term-sheet](https://fortune.com/section/newsletters/term-sheet/) | 创投早报 | 每日 | ⭐⭐⭐⭐ |
| Axios Pro Rata | [axios.com/pro-rata](https://www.axios.com/newsletters/axios-pro-rata) | Dan Primack 的创投早报 | 每日 | ⭐⭐⭐⭐ |

---

## 四、研究机构 / 智库

### 4.1 AI / 前沿研究

| 名称 | 链接 | 内容特点 | 可靠度 |
|-|-|-|-|
| Stanford HAI | [hai.stanford.edu](https://hai.stanford.edu) | 年度《AI Index Report》是行业基准引用最多的报告之一 | ⭐⭐⭐⭐⭐ |
| MIT CSAIL | [csail.mit.edu](https://www.csail.mit.edu) | 论文与项目主页 | ⭐⭐⭐⭐⭐ |
| Berkeley AI Research (BAIR) | [bair.berkeley.edu/blog](https://bair.berkeley.edu/blog/) | 高质量博客 | ⭐⭐⭐⭐⭐ |
| Allen Institute for AI (AI2) | [allenai.org](https://allenai.org) | 开源模型与论文 | ⭐⭐⭐⭐⭐ |
| Epoch AI | [epochai.org](https://epochai.org) | 量化追踪算力、训练成本、模型规模 | ⭐⭐⭐⭐⭐ |
| METR / ARC Evals | [metr.org](https://metr.org) | 前沿模型能力评估 | ⭐⭐⭐⭐⭐ |
| Future of Life Institute | [futureoflife.org](https://futureoflife.org) | AI 安全与政策 | ⭐⭐⭐⭐ |
| Centre for the Governance of AI (GovAI) | [governance.ai](https://www.governance.ai) | AI 治理研究 | ⭐⭐⭐⭐ |
| AI Now Institute | [ainowinstitute.org](https://ainowinstitute.org) | AI 社会影响 | ⭐⭐⭐⭐ |
| Partnership on AI | [partnershiponai.org](https://partnershiponai.org) | 行业治理协作 | ⭐⭐⭐⭐ |

### 4.2 科技 / 产业研究与数据

| 名称 | 链接 | 内容特点 | 可靠度 |
|-|-|-|-|
| Gartner | [gartner.com/en/insights](https://www.gartner.com/en/insights) | 魔力象限、Hype Cycle 行业标尺（多数付费） | ⭐⭐⭐⭐ |
| Forrester | [forrester.com](https://www.forrester.com) | 企业 IT / CX 研究 | ⭐⭐⭐⭐ |
| IDC | [idc.com](https://www.idc.com) | 市场份额数据 | ⭐⭐⭐⭐ |
| McKinsey Global Institute | [mckinsey.com/mgi](https://www.mckinsey.com/mgi/our-research) | 宏观 + 产业的免费长报告 | ⭐⭐⭐⭐⭐ |
| Bain & Company Insights | [bain.com/insights](https://www.bain.com/insights/) | 行业战略报告 | ⭐⭐⭐⭐⭐ |
| BCG Henderson Institute | [bcghendersoninstitute.com](https://www.bcghendersoninstitute.com) | 战略 / 创新研究 | ⭐⭐⭐⭐⭐ |
| Deloitte Insights | [deloitte.com/insights](https://www2.deloitte.com/us/en/insights.html) | 跨行业研究 | ⭐⭐⭐⭐ |
| Bond Internet Trends (Mary Meeker) | [bondcap.com](https://www.bondcap.com) | 互联网趋势年度报告 | ⭐⭐⭐⭐⭐ |
| State of AI Report (Nathan Benaich) | [stateof.ai](https://www.stateof.ai) | 年度 AI 行业全景报告 | ⭐⭐⭐⭐⭐ |
| Air Street Capital Blog | [airstreet.com](https://www.airstreet.com) | AI 投资与研究 | ⭐⭐⭐⭐ |
| SemiAnalysis (Dylan Patel) | [semianalysis.com](https://www.semianalysis.com) | 半导体、AI 算力、数据中心独家深度 | ⭐⭐⭐⭐⭐ |
| TechInsights | [techinsights.com](https://www.techinsights.com) | 半导体逆向分析 | ⭐⭐⭐⭐⭐ |
| Counterpoint Research | [counterpointresearch.com](https://www.counterpointresearch.com) | 智能终端市场份额 | ⭐⭐⭐⭐ |
| Canalys | [canalys.com](https://www.canalys.com) | 终端 / 渠道市场数据 | ⭐⭐⭐⭐ |
| Omdia | [omdia.com](https://omdia.com) | 媒体、半导体、企业 IT 数据 | ⭐⭐⭐⭐ |
| ABI Research | [abiresearch.com](https://www.abiresearch.com) | 物联网、连接性数据 | ⭐⭐⭐⭐ |

### 4.3 政策 / 经济 / 社会智库

| 名称 | 链接 | 内容特点 | 可靠度 |
|-|-|-|-|
| Pew Research Center | [pewresearch.org](https://www.pewresearch.org) | 全球科技与社会调查数据 | ⭐⭐⭐⭐⭐ |
| Brookings | [brookings.edu](https://www.brookings.edu) | 中间偏左的政策智库 | ⭐⭐⭐⭐⭐ |
| RAND Corporation | [rand.org](https://www.rand.org) | 国家安全 / 科技政策深度报告 | ⭐⭐⭐⭐⭐ |
| CSIS | [csis.org](https://www.csis.org) | 地缘政治 + 半导体 / AI 政策 | ⭐⭐⭐⭐⭐ |
| CSET (Georgetown) | [cset.georgetown.edu](https://cset.georgetown.edu) | AI / 算力政策研究金标准 | ⭐⭐⭐⭐⭐ |
| Atlantic Council – GeoTech Center | [atlanticcouncil.org/programs/geotech-center](https://www.atlanticcouncil.org/programs/geotech-center/) | 地缘政治 × 科技 | ⭐⭐⭐⭐⭐ |
| Council on Foreign Relations | [cfr.org](https://www.cfr.org) | 国际关系背景下的科技议题 | ⭐⭐⭐⭐⭐ |
| OECD AI Policy Observatory | [oecd.ai](https://oecd.ai) | 各国 AI 政策与统计 | ⭐⭐⭐⭐⭐ |
| World Economic Forum | [weforum.org](https://www.weforum.org) | 全球议题报告（Davos 系） | ⭐⭐⭐⭐ |
| IMF Blog | [imf.org/en/Blogs](https://www.imf.org/en/Blogs) | 宏观经济与科技对生产力影响 | ⭐⭐⭐⭐⭐ |
| BIS – Bank for International Settlements | [bis.org](https://www.bis.org) | "央行的央行"，金融科技与稳定币 | ⭐⭐⭐⭐⭐ |
| NBER Working Papers | [nber.org/papers](https://www.nber.org/papers) | 经济学论文一手 | ⭐⭐⭐⭐⭐ |

---

## 五、新闻聚合 / 数据库 / 工具

| 名称 | 链接 | 角色 | 用法 | 可靠度 |
|-|-|-|-|-|
| Hacker News | [news.ycombinator.com](https://news.ycombinator.com) | ⚡🔭 | 工程师社区首选首页，评论区 > 文章本身 | ⭐⭐ |
| Techmeme | [techmeme.com](https://www.techmeme.com) | ⚡ | 科技新闻聚合"事实板"，每条都给出多家来源 | ⭐⭐⭐⭐ |
| Memeorandum | [memeorandum.com](https://www.memeorandum.com) | ⚡ | 政治 / 商业新闻聚合 | ⭐⭐⭐ |
| Mediagazer | [mediagazer.com](https://www.mediagazer.com) | ⚡ | 媒体行业聚合 | ⭐⭐⭐ |
| Feedly | [feedly.com](https://feedly.com) | 工具 | RSS 阅读器 | — |
| Inoreader | [inoreader.com](https://www.inoreader.com) | 工具 | RSS 阅读器 | — |
| Pocket | [getpocket.com](https://getpocket.com) | 工具 | 稍后读 | — |
| Readwise Reader | [readwise.io/read](https://readwise.io/read) | 工具 | 稍后读 / 长文阅读 / 高亮同步 | — |
| Smartr Daily | [smartr.tech](https://smartr.tech) | ⚡ | 科技新闻精选 | ⭐⭐⭐ |
| Lobsters | [lobste.rs](https://lobste.rs) | 🔭 | 邀请制工程师社区，比 HN 更聚焦 | ⭐⭐⭐ |
| Slashdot | [slashdot.org](https://slashdot.org) | 🔭 | 老牌工程社区 | ⭐⭐ |
| Wikipedia – Current Events | [en.wikipedia.org/wiki/Portal:Current_events](https://en.wikipedia.org/wiki/Portal:Current_events) | ⚡ | 中性事实底稿 | ⭐⭐⭐⭐ |
| Our World in Data | [ourworldindata.org](https://ourworldindata.org) | 📚 | 全球长期数据可视化 | ⭐⭐⭐⭐⭐ |
| Statista | [statista.com](https://www.statista.com) | 📚 | 各类统计数据库（多数付费） | ⭐⭐⭐⭐ |
| Visual Capitalist | [visualcapitalist.com](https://www.visualcapitalist.com) | 🔭 | 商业 / 经济数据可视化 | ⭐⭐⭐ |
| Product Hunt | [producthunt.com](https://www.producthunt.com) | ⚡ | 新产品发布榜 | ⭐⭐ |

---

## 六、论坛 / 社区

### 6.1 综合科技 / 创业

| 名称 | 链接 | 特点 | 可靠度 |
|-|-|-|-|
| Hacker News | [news.ycombinator.com](https://news.ycombinator.com) | YC 旗下，工程师 / 创业者首选；Show HN 经常是早期独立产品 | ⭐⭐ |
| Lobsters | [lobste.rs](https://lobste.rs) | 邀请制，技术更专 | ⭐⭐⭐ |
| r/programming | [reddit.com/r/programming](https://www.reddit.com/r/programming) | 程序员综合 | ⭐⭐ |
| r/technology | [reddit.com/r/technology](https://www.reddit.com/r/technology) | 大众科技 | ⭐⭐ |
| r/startups | [reddit.com/r/startups](https://www.reddit.com/r/startups) | 创业讨论 | ⭐⭐ |
| r/Entrepreneur | [reddit.com/r/Entrepreneur](https://www.reddit.com/r/Entrepreneur) | 创业 | ⭐⭐ |
| Indie Hackers | [indiehackers.com](https://www.indiehackers.com) | 独立开发者收入与故事 | ⭐⭐⭐ |
| Designer News | [news.layervault.com](https://news.layervault.com) | 设计师社区（活跃度下降） | ⭐⭐ |

### 6.2 AI / ML 社区

| 名称 | 链接 | 特点 | 可靠度 |
|-|-|-|-|
| r/MachineLearning | [reddit.com/r/MachineLearning](https://www.reddit.com/r/MachineLearning) | 学术 + 工程，质量较高 | ⭐⭐⭐ |
| r/LocalLLaMA | [reddit.com/r/LocalLLaMA](https://www.reddit.com/r/LocalLLaMA) | 本地大模型与开源生态信息密度极高 | ⭐⭐⭐ |
| r/StableDiffusion | [reddit.com/r/StableDiffusion](https://www.reddit.com/r/StableDiffusion) | 图像生成社区 | ⭐⭐ |
| r/singularity | [reddit.com/r/singularity](https://www.reddit.com/r/singularity) | 信噪比一般但能感知大众情绪 | ⭐ |
| Hugging Face Forums | [discuss.huggingface.co](https://discuss.huggingface.co) | 工程问题与发布 | ⭐⭐⭐⭐ |
| LessWrong | [lesswrong.com](https://www.lesswrong.com) | AI 安全 / 对齐讨论核心社区 | ⭐⭐⭐⭐ |
| Alignment Forum | [alignmentforum.org](https://www.alignmentforum.org) | 学术化对齐讨论 | ⭐⭐⭐⭐⭐ |
| EleutherAI Discord | [eleuther.ai](https://www.eleuther.ai) | 开源 LLM 重要据点 | ⭐⭐⭐⭐ |
| LangChain Discord | [langchain.com](https://www.langchain.com) | 应用开发者 | ⭐⭐⭐ |

### 6.3 商业 / 投资社区

| 名称 | 链接 | 特点 | 可靠度 |
|-|-|-|-|
| r/investing | [reddit.com/r/investing](https://www.reddit.com/r/investing) | 综合二级 | ⭐⭐ |
| r/SecurityAnalysis | [reddit.com/r/SecurityAnalysis](https://www.reddit.com/r/SecurityAnalysis) | 价值投资文献 | ⭐⭐⭐ |
| Value Investors Club (VIC) | [valueinvestorsclub.com](https://www.valueinvestorsclub.com) | 高质量长持有研究（需申请） | ⭐⭐⭐⭐⭐ |
| Bogleheads | [bogleheads.org](https://www.bogleheads.org) | 长期被动投资 | ⭐⭐⭐⭐ |

---

## 七、YouTube 频道

### 7.1 科技评测 / 产品

| 频道 | 链接 | 内容特点 | 更新频率 | 可靠度 |
|-|-|-|-|-|
| Marques Brownlee (MKBHD) | [youtube.com/@mkbhd](https://www.youtube.com/@mkbhd) | 顶级消费电子评测，制作工艺标杆 | 周更多次 | ⭐⭐⭐⭐ |
| Linus Tech Tips | [youtube.com/@LinusTechTips](https://www.youtube.com/@LinusTechTips) | PC / 硬件评测 | 每日 | ⭐⭐⭐ |
| The Verge | [youtube.com/@TheVerge](https://www.youtube.com/@TheVerge) | 评测 + 解释类视频 | 每周多更 | ⭐⭐⭐ |
| Engadget | [youtube.com/@engadget](https://www.youtube.com/@engadget) | 消费电子 | 每周 | ⭐⭐ |
| Mrwhosetheboss | [youtube.com/@Mrwhosetheboss](https://www.youtube.com/@Mrwhosetheboss) | 流行科技评测，选题广 | 周更 | ⭐⭐⭐ |
| Austin Evans | [youtube.com/@austinevans](https://www.youtube.com/@austinevans) | 消费数码 | 周更 | ⭐⭐⭐ |
| Dave2D | [youtube.com/@Dave2D](https://www.youtube.com/@Dave2D) | 笔记本测评 | 周更 | ⭐⭐⭐ |
| iJustine | [youtube.com/@ijustine](https://www.youtube.com/@ijustine) | Apple 生态 | 周更 | ⭐⭐ |
| Snazzy Labs | [youtube.com/@SnazzyLabs](https://www.youtube.com/@SnazzyLabs) | 苹果与生产力 | 周更 | ⭐⭐⭐ |
| ColdFusion | [youtube.com/@ColdFusion](https://www.youtube.com/@ColdFusion) | 科技与商业纪录片式叙事 | 周更 | ⭐⭐⭐⭐ |
| Veritasium | [youtube.com/@veritasium](https://www.youtube.com/@veritasium) | 科学与技术原理深度 | 月更多次 | ⭐⭐⭐⭐⭐ |
| Real Engineering | [youtube.com/@RealEngineering](https://www.youtube.com/@RealEngineering) | 工程原理纪录片 | 月更 | ⭐⭐⭐⭐ |
| Asianometry | [youtube.com/@Asianometry](https://www.youtube.com/@Asianometry) | 半导体史与产业链科普，质量极高 | 周更 | ⭐⭐⭐⭐⭐ |
| TechAltar | [youtube.com/@TechAltar](https://www.youtube.com/@TechAltar) | 移动产业分析 | 月更多次 | ⭐⭐⭐⭐ |
| Cleo Abram (Huge If True) | [youtube.com/@CleoAbram](https://www.youtube.com/@CleoAbram) | 前 Vox 记者，科技与社会议题 | 月更 | ⭐⭐⭐⭐ |

### 7.2 软件开发 / Geek

| 频道 | 链接 | 内容特点 | 可靠度 |
|-|-|-|-|
| Fireship | [youtube.com/@Fireship](https://www.youtube.com/@Fireship) | 100 秒科普 + Web 技术快讯 | ⭐⭐⭐ |
| ThePrimeagen | [youtube.com/@ThePrimeagen](https://www.youtube.com/@ThePrimeagen) | 工程师文化、源码阅读 | ⭐⭐⭐ |
| Theo – t3.gg | [youtube.com/@t3dotgg](https://www.youtube.com/@t3dotgg) | Web 工程意见领袖，AI 工程话题多 | ⭐⭐⭐ |
| Computerphile | [youtube.com/@Computerphile](https://www.youtube.com/@Computerphile) | 计算机科学经典科普 | ⭐⭐⭐⭐⭐ |
| Numberphile | [youtube.com/@numberphile](https://www.youtube.com/@numberphile) | 数学科普 | ⭐⭐⭐⭐⭐ |
| 3Blue1Brown | [youtube.com/@3blue1brown](https://www.youtube.com/@3blue1brown) | 数学与神经网络可视化经典 | ⭐⭐⭐⭐⭐ |
| Mental Outlaw | [youtube.com/@MentalOutlaw](https://www.youtube.com/@MentalOutlaw) | 隐私与开源 | ⭐⭐ |
| NetworkChuck | [youtube.com/@NetworkChuck](https://www.youtube.com/@NetworkChuck) | 网络与安全教程 | ⭐⭐⭐ |
| LiveOverflow | [youtube.com/@LiveOverflow](https://www.youtube.com/@LiveOverflow) | 安全研究 | ⭐⭐⭐⭐ |

### 7.3 AI / 机器学习

| 频道 | 链接 | 内容特点 | 可靠度 |
|-|-|-|-|
| Andrej Karpathy | [youtube.com/@AndrejKarpathy](https://www.youtube.com/@AndrejKarpathy) | 大模型 / nanoGPT 系列教程，AI 工程师必看 | ⭐⭐⭐⭐⭐ |
| Two Minute Papers | [youtube.com/@TwoMinutePapers](https://www.youtube.com/@TwoMinutePapers) | 论文要点视频 | ⭐⭐⭐ |
| Yannic Kilcher | [youtube.com/@YannicKilcher](https://www.youtube.com/@YannicKilcher) | 论文逐段解读，工程师友好 | ⭐⭐⭐⭐ |
| AI Explained | [youtube.com/@aiexplained-official](https://www.youtube.com/@aiexplained-official) | 综合性 AI 进展解读，引用扎实 | ⭐⭐⭐⭐ |
| Matt Wolfe | [youtube.com/@mreflow](https://www.youtube.com/@mreflow) | AI 工具综述（偏大众） | ⭐⭐ |
| Matthew Berman | [youtube.com/@matthew_berman](https://www.youtube.com/@matthew_berman) | 每日跟进 AI 新闻、模型评测与工具实测 | ⭐⭐⭐ |
| The AI Advantage | [youtube.com/@aiadvantage](https://www.youtube.com/@aiadvantage) | AI 应用层教程 | ⭐⭐ |
| All About AI | [youtube.com/@AllAboutAI](https://www.youtube.com/@AllAboutAI) | LLM 应用工程 | ⭐⭐⭐ |
| Sentdex | [youtube.com/@sentdex](https://www.youtube.com/@sentdex) | Python ML 教程经典 | ⭐⭐⭐⭐ |
| StatQuest | [youtube.com/@statquest](https://www.youtube.com/@statquest) | 统计与 ML 直观讲解 | ⭐⭐⭐⭐⭐ |
| Machine Learning Street Talk | [youtube.com/@MachineLearningStreetTalk](https://www.youtube.com/@MachineLearningStreetTalk) | 学术访谈深度 | ⭐⭐⭐⭐ |
| Lex Fridman | [youtube.com/@lexfridman](https://www.youtube.com/@lexfridman) | 长访谈（AI、科学、商业、政治） | ⭐⭐⭐ |
| Dwarkesh Patel | [youtube.com/@DwarkeshPatel](https://www.youtube.com/@DwarkeshPatel) | 与一线 AI 研究者深度访谈，质量极高 | ⭐⭐⭐⭐⭐ |
| Latent Space | [youtube.com/@LatentSpacePod](https://www.youtube.com/@LatentSpacePod) | AI 工程师播客视频版 | ⭐⭐⭐⭐ |
| No Priors | [youtube.com/@NoPriorsPodcast](https://www.youtube.com/@NoPriorsPodcast) | Sarah Guo & Elad Gil 的 AI 投资访谈 | ⭐⭐⭐⭐ |
| Cognitive Revolution | [youtube.com/@CognitiveRevolutionPodcast](https://www.youtube.com/@CognitiveRevolutionPodcast) | AI 行业访谈 | ⭐⭐⭐⭐ |
| Hard Fork | https://www.youtube.com/@hardfork | NYT 出品，由 Kevin Roose 和 Casey Newton 主持，是目前全美收听率和质量最高的 AI / 科技播客之一 | ⭐⭐⭐⭐⭐ |

### 7.4 商业 / 投资 / 创业

| 频道 | 链接 | 内容特点 | 可靠度 |
|-|-|-|-|
| All-In Podcast | [youtube.com/@allin](https://www.youtube.com/@allin) | Chamath/Sacks/Friedberg/Calacanis，注意立场 | ⭐ |
| 20VC – Harry Stebbings | [youtube.com/@20vc](https://www.youtube.com/@20vc) | 顶级 VC 访谈 | ⭐⭐⭐⭐ |
| The Diary of a CEO | [youtube.com/@TheDiaryOfACEO](https://www.youtube.com/@TheDiaryOfACEO) | CEO 长访谈（偏大众） | ⭐⭐⭐ |
| My First Million | [youtube.com/@MyFirstMillionPod](https://www.youtube.com/@MyFirstMillionPod) | 创业 Idea + 商业拆解 | ⭐⭐⭐ |
| The Knowledge Project (Shane Parrish) | [youtube.com/@theknowledgeproject](https://www.youtube.com/@theknowledgeproject) | 思维模型与高质量访谈 | ⭐⭐⭐⭐ |
| How I Built This | [youtube.com/@HowIBuiltThis](https://www.youtube.com/@HowIBuiltThis) | 创业故事 | ⭐⭐⭐⭐ |
| Acquired | [youtube.com/@AcquiredFM](https://www.youtube.com/@AcquiredFM) | 公司史长视频（Nvidia/TSMC/Costco 等） | ⭐⭐⭐⭐⭐ |
| Modern Wisdom | [youtube.com/@ChrisWillx](https://www.youtube.com/@ChrisWillx) | 长访谈（思想、商业、科学） | ⭐⭐⭐ |
| The Tim Ferriss Show | [youtube.com/@timferriss](https://www.youtube.com/@timferriss) | 顶级人物访谈 | ⭐⭐⭐⭐ |
| Patrick Boyle on Finance | [youtube.com/@PBoyle](https://www.youtube.com/@PBoyle) | 金融现实主义评论 | ⭐⭐⭐⭐ |
| New Money | [youtube.com/@NewMoneyYT](https://www.youtube.com/@NewMoneyYT) | 商业战略案例分析 | ⭐⭐⭐ |

### 7.5 财经 / 宏观

| 频道 | 链接 | 内容特点 | 可靠度 |
|-|-|-|-|
| Bloomberg Television | [youtube.com/@markets](https://www.youtube.com/@markets) | 实时财经 | ⭐⭐⭐⭐⭐ |
| Bloomberg Originals | [youtube.com/@business](https://www.youtube.com/@business) | 长纪录片质量很高 | ⭐⭐⭐⭐⭐ |
| CNBC | [youtube.com/@CNBC](https://www.youtube.com/@CNBC) | 美股财经 | ⭐⭐⭐⭐ |
| CNBC Television | [youtube.com/@CNBCtelevision](https://www.youtube.com/@CNBCtelevision) | 直播片段，CEO 访谈 | ⭐⭐⭐⭐ |
| Yahoo Finance | [youtube.com/@yahoofinance](https://www.youtube.com/@yahoofinance) | 美股 | ⭐⭐⭐ |
| Financial Times | [youtube.com/@financialtimes](https://www.youtube.com/@financialtimes) | FT 视频版 | ⭐⭐⭐⭐⭐ |
| The Wall Street Journal | [youtube.com/@wsj](https://www.youtube.com/@wsj) | WSJ 视频解释 | ⭐⭐⭐⭐⭐ |
| The Economist | [youtube.com/@TheEconomist](https://www.youtube.com/@TheEconomist) | 解释类视频 | ⭐⭐⭐⭐⭐ |
| Reuters | [youtube.com/@Reuters](https://www.youtube.com/@Reuters) | 通讯社视频 | ⭐⭐⭐⭐⭐ |
| Joseph Carlson | [youtube.com/@JosephCarlsonShow](https://www.youtube.com/@JosephCarlsonShow) | 美股个人投资视角 | ⭐⭐⭐ |
| Money & Macro | [youtube.com/@MoneyMacro](https://www.youtube.com/@MoneyMacro) | 宏观经济解释 | ⭐⭐⭐⭐ |

---

## 八、X (Twitter) 必关注账号

> **提示**：X 信噪比波动很大。建议：① 只关注个人账号，公司账号订阅 RSS 即可；② 利用 List 分类（AI Researchers / VC / Reporters / Macro / Founders）；③ 对匿名运营号保持警惕。

### 8.1 AI 研究 / 工程领袖

| 账号 | 链接 | 介绍 | 可靠度 |
|-|-|-|-|
| Andrej Karpathy @karpathy | [x.com/karpathy](https://x.com/karpathy) | 前 OpenAI / Tesla AI，教程级解释 | ⭐⭐⭐⭐⭐ |
| Yann LeCun @ylecun | [x.com/ylecun](https://x.com/ylecun) | Meta 首席 AI 科学家，图灵奖得主 | ⭐⭐⭐⭐⭐ |
| Andrew Ng @AndrewYNg | [x.com/AndrewYNg](https://x.com/AndrewYNg) | DeepLearning.AI 创始人 | ⭐⭐⭐⭐⭐ |
| Demis Hassabis @demishassabis | [x.com/demishassabis](https://x.com/demishassabis) | DeepMind CEO，诺贝尔化学奖得主 | ⭐⭐⭐⭐⭐ |
| Jeff Dean @JeffDean | [x.com/JeffDean](https://x.com/JeffDean) | Google 首席科学家 | ⭐⭐⭐⭐⭐ |
| Sam Altman @sama | [x.com/sama](https://x.com/sama) | OpenAI CEO | ⭐⭐⭐⭐ |
| Ilya Sutskever @ilyasut | [x.com/ilyasut](https://x.com/ilyasut) | SSI 创始人，前 OpenAI 联创 | ⭐⭐⭐⭐⭐ |
| Dario Amodei @DarioAmodei | [x.com/DarioAmodei](https://x.com/DarioAmodei) | Anthropic CEO | ⭐⭐⭐⭐⭐ |
| Jack Clark @jackclarkSF | [x.com/jackclarkSF](https://x.com/jackclarkSF) | Anthropic 联创，Import AI 作者 | ⭐⭐⭐⭐⭐ |
| Sebastian Raschka @rasbt | [x.com/rasbt](https://x.com/rasbt) | LLM 教学 / 工程 | ⭐⭐⭐⭐ |
| Lilian Weng @lilianweng | [x.com/lilianweng](https://x.com/lilianweng) | 前 OpenAI 安全研究 | ⭐⭐⭐⭐⭐ |
| Harrison Chase @hwchase17 | [x.com/hwchase17](https://x.com/hwchase17) | LangChain 创始人 | ⭐⭐⭐ |
| swyx @swyx | [x.com/swyx](https://x.com/swyx) | Latent Space，AI 工程师社区策展 | ⭐⭐⭐⭐ |
| Simon Willison @simonw | [x.com/simonw](https://x.com/simonw) | 每天追 LLM 实践 | ⭐⭐⭐⭐⭐ |
| AK @\_akhaliq | [x.com/\_akhaliq](https://x.com/_akhaliq) | HuggingFace，每日转发新论文 | ⭐⭐⭐⭐ |
| Aran Komatsuzaki @arankomatsuzaki | [x.com/arankomatsuzaki](https://x.com/arankomatsuzaki) | 论文跟踪 | ⭐⭐⭐⭐ |
| Arvind Narayanan @random_walker | [x.com/random_walker](https://x.com/random_walker) | Princeton，AI Snake Oil 作者 | ⭐⭐⭐⭐⭐ |
| Jim Fan @DrJimFan | [x.com/DrJimFan](https://x.com/DrJimFan) | NVIDIA 高级研究员，具身智能 | ⭐⭐⭐⭐ |
| François Chollet @fchollet | [x.com/fchollet](https://x.com/fchollet) | Keras 作者、ARC 测试发起人 | ⭐⭐⭐⭐⭐ |
| David Ha @hardmaru | [x.com/hardmaru](https://x.com/hardmaru) | Sakana AI CEO | ⭐⭐⭐⭐ |
| Arthur Mensch @arthurmensch | [x.com/arthurmensch](https://x.com/arthurmensch) | Mistral CEO | ⭐⭐⭐⭐ |
| Clement Delangue @ClementDelangue | [x.com/ClementDelangue](https://x.com/ClementDelangue) | Hugging Face CEO | ⭐⭐⭐⭐ |
| Tri Dao @tri_dao | [x.com/tri_dao](https://x.com/tri_dao) | FlashAttention 作者 | ⭐⭐⭐⭐⭐ |
| Aravind Srinivas @AravSrinivas | [x.com/AravSrinivas](https://x.com/AravSrinivas) | Perplexity CEO | ⭐⭐⭐ |
| Soumith Chintala @soumithchintala | [x.com/soumithchintala](https://x.com/soumithchintala) | PyTorch 联合作者 | ⭐⭐⭐⭐⭐ |
| Geoffrey Hinton @geoffreyhinton | [x.com/geoffreyhinton](https://x.com/geoffreyhinton) | 图灵奖得主 | ⭐⭐⭐⭐⭐ |
| Ethan Mollick @emollick | [x.com/emollick](https://x.com/emollick) | 沃顿教授，LLM 在工作流的应用 | ⭐⭐⭐⭐ |

### 8.2 半导体 / 算力 / 基础设施

| 账号 | 链接 | 介绍 | 可靠度 |
|-|-|-|-|
| Dylan Patel @dylan522p | [x.com/dylan522p](https://x.com/dylan522p) | SemiAnalysis，半导体一线深度 | ⭐⭐⭐⭐⭐ |
| Alexandr Wang @alexandr_wang | [x.com/alexandr_wang](https://x.com/alexandr_wang) | Scale AI CEO | ⭐⭐⭐⭐ |
| Jon Erlichman @JonErlichman | [x.com/JonErlichman](https://x.com/JonErlichman) | 科技公司财报数据 | ⭐⭐⭐⭐ |

### 8.3 科技公司高管 / 创始人

| 账号 | 链接 | 介绍 | 可靠度 |
|-|-|-|-|
| Satya Nadella @satyanadella | [x.com/satyanadella](https://x.com/satyanadella) | Microsoft CEO | ⭐⭐⭐⭐ |
| Tim Cook @tim_cook | [x.com/tim_cook](https://x.com/tim_cook) | Apple CEO | ⭐⭐⭐ |
| Elon Musk @elonmusk | [x.com/elonmusk](https://x.com/elonmusk) | Tesla/SpaceX/xAI（注意立场） | ⭐ |
| Patrick Collison @patrickc | [x.com/patrickc](https://x.com/patrickc) | Stripe CEO | ⭐⭐⭐⭐⭐ |
| Paul Graham @paulg | [x.com/paulg](https://x.com/paulg) | YC 创始人，创业经典文章 | ⭐⭐⭐⭐⭐ |
| Garry Tan @garrytan | [x.com/garrytan](https://x.com/garrytan) | YC 现任 CEO | ⭐⭐⭐⭐ |
| Marc Andreessen @pmarca | [x.com/pmarca](https://x.com/pmarca) | a16z 创始人 | ⭐⭐⭐ |
| Reid Hoffman @reidhoffman | [x.com/reidhoffman](https://x.com/reidhoffman) | LinkedIn 创始人 | ⭐⭐⭐⭐ |
| Bill Gurley @bgurley | [x.com/bgurley](https://x.com/bgurley) | Benchmark | ⭐⭐⭐⭐⭐ |
| Fred Wilson @fredwilson | [x.com/fredwilson](https://x.com/fredwilson) | USV | ⭐⭐⭐⭐⭐ |
| Naval Ravikant @naval | [x.com/naval](https://x.com/naval) | AngelList 创始人，思想型创业 | ⭐⭐⭐⭐ |
| Keith Rabois @rabois | [x.com/rabois](https://x.com/rabois) | Founders Fund | ⭐⭐⭐ |
| Chamath Palihapitiya @chamath | [x.com/chamath](https://x.com/chamath) | Social Capital / All-In | ⭐⭐ |
| David Sacks @davidsacks | [x.com/davidsacks](https://x.com/davidsacks) | Craft Ventures / All-In | ⭐⭐ |
| Vinod Khosla @vkhosla | [x.com/vkhosla](https://x.com/vkhosla) | Khosla Ventures | ⭐⭐⭐⭐ |
| Brian Armstrong @brian_armstrong | [x.com/brian_armstrong](https://x.com/brian_armstrong) | Coinbase CEO | ⭐⭐⭐ |
| Tobi Lütke @tobi | [x.com/tobi](https://x.com/tobi) | Shopify CEO | ⭐⭐⭐⭐ |
| Sarah Guo @saranormous | [x.com/saranormous](https://x.com/saranormous) | Conviction VC，No Priors 主持 | ⭐⭐⭐⭐ |
| Elad Gil @eladgil | [x.com/eladgil](https://x.com/eladgil) | 多产天使投资人 | ⭐⭐⭐⭐ |
| Aaron Levie @levie | [x.com/levie](https://x.com/levie) | Box CEO，SaaS 与 AI 转型 | ⭐⭐⭐ |
| Brad Gerstner @altcap | [x.com/altcap](https://x.com/altcap) | Altimeter 创始人 | ⭐⭐⭐⭐ |
| Steven Sinofsky @stevesi | [x.com/stevesi](https://x.com/stevesi) | 前微软 Windows 部门负责人 | ⭐⭐⭐⭐⭐ |
| Dan Shipper @danshipper | [x.com/danshipper](https://x.com/danshipper) | Every 主理人 | ⭐⭐⭐⭐ |
| Lenny Rachitsky @lennysan | [x.com/lennysan](https://x.com/lennysan) | PM 领域顶流 | ⭐⭐⭐⭐ |

### 8.4 商业 / 战略 / 媒体观察

| 账号 | 链接 | 介绍 | 可靠度 |
|-|-|-|-|
| Ben Thompson @benthompson | [x.com/benthompson](https://x.com/benthompson) | Stratechery 作者 | ⭐⭐⭐⭐⭐ |
| Benedict Evans @benedictevans | [x.com/benedictevans](https://x.com/benedictevans) | 科技行业宏观趋势，数据 + 图表风 | ⭐⭐⭐⭐⭐ |
| Casey Newton @CaseyNewton | [x.com/CaseyNewton](https://x.com/CaseyNewton) | Platformer | ⭐⭐⭐⭐⭐ |
| Kara Swisher @karaswisher | [x.com/karaswisher](https://x.com/karaswisher) | 资深科技记者 | ⭐⭐⭐⭐ |
| Mark Gurman @markgurman | [x.com/markgurman](https://x.com/markgurman) | Bloomberg 苹果情报记者 | ⭐⭐⭐⭐⭐ |
| Kevin Roose @kevinroose | [x.com/kevinroose](https://x.com/kevinroose) | NYT Tech 主笔 | ⭐⭐⭐⭐⭐ |
| Matt Levine @matt_levine | [x.com/matt_levine](https://x.com/matt_levine) | Money Stuff | ⭐⭐⭐⭐⭐ |
| Byrne Hobart @byrnehobart | [x.com/byrnehobart](https://x.com/byrnehobart) | The Diff | ⭐⭐⭐⭐⭐ |
| Packy McCormick @packyM | [x.com/packyM](https://x.com/packyM) | Not Boring | ⭐⭐⭐⭐ |
| Erin Griffith @eringriffith | [x.com/eringriffith](https://x.com/eringriffith) | NYT 创投记者 | ⭐⭐⭐⭐⭐ |
| Teddy Schleifer @teddyschleifer | [x.com/teddyschleifer](https://x.com/teddyschleifer) | Puck 创投科技记者 | ⭐⭐⭐⭐ |
| Paris Marx @parismarx | [x.com/parismarx](https://x.com/parismarx) | Tech Won't Save Us，批评型评论 | ⭐⭐⭐ |
| Joe Weisenthal @TheStalwart | [x.com/TheStalwart](https://x.com/TheStalwart) | Bloomberg / Odd Lots | ⭐⭐⭐⭐⭐ |
| Tracy Alloway @tracyalloway | [x.com/tracyalloway](https://x.com/tracyalloway) | Bloomberg / Odd Lots | ⭐⭐⭐⭐⭐ |

### 8.5 财经 / 宏观 / 投资

| 账号 | 链接 | 介绍 | 可靠度 |
|-|-|-|-|
| Liz Ann Sonders @LizAnnSonders | [x.com/LizAnnSonders](https://x.com/LizAnnSonders) | Charles Schwab 首席投资策略师 | ⭐⭐⭐⭐⭐ |
| Charlie Bilello @charliebilello | [x.com/charliebilello](https://x.com/charliebilello) | 市场数据图 | ⭐⭐⭐⭐ |
| Michael Batnick @michaelbatnick | [x.com/michaelbatnick](https://x.com/michaelbatnick) | The Irrelevant Investor | ⭐⭐⭐⭐ |

### 8.6 中国 / 亚太科技产业（英文）

| 账号 | 链接 | 介绍 | 可靠度 |
|-|-|-|-|
| Bill Bishop @niubi | [x.com/niubi](https://x.com/niubi) | Sinocism 作者 | ⭐⭐⭐⭐⭐ |
| Rui Ma @ruima | [x.com/ruima](https://x.com/ruima) | Tech Buzz China 主持 | ⭐⭐⭐⭐ |
| Lillian Li @lillianmli | [x.com/lillianmli](https://x.com/lillianmli) | Chinese Characteristics 作者 | ⭐⭐⭐⭐ |
| Matt Sheehan @MattSheehan88 | [x.com/MattSheehan88](https://x.com/MattSheehan88) | Carnegie，AI × 中国政策 | ⭐⭐⭐⭐⭐ |
| Jordan Schneider @jordanschnyc | [x.com/jordanschnyc](https://x.com/jordanschnyc) | ChinaTalk 主持 | ⭐⭐⭐⭐ |

### 8.7 中文圈优质账号

| 账号 | 链接 | 介绍 | 可靠度 |
|-|-|-|-|
| 宝玉 @dotey | [x.com/dotey](https://x.com/dotey) | 资深工程师，海外 AI 技术翻译解读 | ⭐⭐⭐⭐ |
| idoubi @idoubicc | [x.com/idoubicc](https://x.com/idoubicc) | 独立开发者，AI 应用实战 | ⭐⭐⭐ |
| Bear Liu @Bear_Liu | [x.com/Bear_Liu](https://x.com/Bear_Liu) | 资深产品人，产品方法论 | ⭐⭐⭐ |
| 歸藏 (guizang) @op7418 | [x.com/op7418](https://x.com/op7418) | AI 工具与设计圈 | ⭐⭐⭐ |
| Yangyi @yangyixxxx | [x.com/yangyixxxx](https://x.com/yangyixxxx) | AI 产品与商业模式 | ⭐⭐⭐ |
| fin @FinanceYF5 | [x.com/FinanceYF5](https://x.com/FinanceYF5) | 美股、宏观与科技的中文金融视角 | ⭐⭐⭐ |
| 橘鸦 Juya @oran_ge | [x.com/oran_ge](https://x.com/oran_ge) | AI Agent 与开发者工具 | ⭐⭐⭐ |

---

## 九、中文 / 华语优质来源

### 9.1 中文科技 & 财经媒体

| 名称 | 链接 | 角色 | 内容特点 | 可靠度 |
|-|-|-|-|-|
| 36 氪 | [36kr.com](https://36kr.com) | ⚡💰 | 创投快讯、企业报道，覆盖面广 | ⭐⭐⭐ |
| 极客公园 | [geekpark.net](https://www.geekpark.net) | 🔭 | 科技与产品深度分析 | ⭐⭐⭐ |
| 品玩 PingWest | [pingwest.com](https://www.pingwest.com) | 🔭 | 中美科技桥梁视角 | ⭐⭐⭐ |
| 虎嗅 | [huxiu.com](https://www.huxiu.com) | ⚡🔭 | 偏商业与互联网产业 | ⭐⭐ |
| 钛媒体 | [tmtpost.com](https://www.tmtpost.com) | ⚡ | 科技商业综合 | ⭐⭐ |
| 少数派 | [sspai.com](https://sspai.com) | 🔭 | 效率工具与数码生活 | ⭐⭐⭐ |
| 爱范儿 ifanr | [ifanr.com](https://www.ifanr.com) | ⚡ | 消费电子与产品 | ⭐⭐⭐ |
| 晚点 LatePost | [latepost.com](https://www.latepost.com) | 📊 | 中国互联网/AI 大厂深度调查，质量极高 | ⭐⭐⭐⭐⭐ |
| 财新 Caixin | [caixin.com](https://www.caixin.com) | 📊 | 中国最严肃的财经调查媒体 | ⭐⭐⭐⭐⭐ |
| 第一财经 | [yicai.com](https://www.yicai.com) | ⚡ | 财经快讯 | ⭐⭐⭐⭐ |
| 界面新闻 | [jiemian.com](https://www.jiemian.com) | ⚡ | 商业与科技综合 | ⭐⭐⭐ |
| 知危 | [zhiweidata.com](https://www.zhiweidata.com) | 📊 | 偏严肃的商业调查与公司研究 | ⭐⭐⭐⭐ |
| 机器之心 Synced | [jiqizhixin.com](https://www.jiqizhixin.com) | 📊📚 | AI 行业翻译 + 产业报道 | ⭐⭐⭐⭐ |
| 量子位 QbitAI | [qbitai.com](https://www.qbitai.com) | ⚡ | AI 快讯 | ⭐⭐⭐ |
| 新智元 | [ai-era.com](https://www.ai-era.com) | ⚡ | AI 快讯（注意营销成分） | ⭐ |
| 智源社区 BAAI | [hub.baai.ac.cn](https://hub.baai.ac.cn) | 📚 | 北京智源，学术前沿 | ⭐⭐⭐⭐⭐ |
| 雷峰网 | [leiphone.com](https://www.leiphone.com) | 🔭 | AI 与硬科技 | ⭐⭐⭐ |
| InfoQ 中文 | [infoq.cn](https://www.infoq.cn) | 📊 | 企业级技术、架构与工程实践 | ⭐⭐⭐⭐ |
| CSDN（精选） | [csdn.net](https://www.csdn.net) | 🔭 | 开发者社区（质量分散） | ⭐ |
| V2EX | [v2ex.com](https://www.v2ex.com) | 🔭 | 中文开发者社区 | ⭐⭐ |
| 即刻 | [web.okjike.com](https://web.okjike.com) | 🔭 | 中文产品/AI 圈活跃兴趣社区 | ⭐⭐ |

### 9.2 中文 Newsletter / 独立博客

| 名称 | 链接 | 内容特点 | 可靠度 |
|-|-|-|-|
| 湾区日报（已停更但存档好） | [wanqu.co](https://wanqu.co) | 每日精选 5 篇英文文章+中文点评 | ⭐⭐⭐⭐ |
| 产品沉思录 | [pmthinking.com](https://www.pmthinking.com) | 产品与思维模型 | ⭐⭐⭐⭐ |
| 小报童精选 | [xiaobot.net](https://xiaobot.net) | 中文 Newsletter 平台 | ⭐⭐⭐ |
| Founder Park | 微信公众号 | AI 产品与创业（极客公园下属） | ⭐⭐⭐ |
| 宝玉的分享 | [x.com/dotey](https://x.com/dotey) | AI 优质内容翻译和分享 | ⭐⭐⭐⭐ |
| Yam AI Newsletter | [yam.ai](https://yam.ai) | AI 简报 | ⭐⭐⭐ |

### 9.3 中文播客

| 播客 | 平台 | 内容特点 | 可靠度 |
|-|-|-|-|
| 商业就是这样 | [小宇宙](https://www.xiaoyuzhoufm.com/podcast/6013f9f58e2f7ee375cf4216) | 商业案例深度 | ⭐⭐⭐⭐ |
| 硅谷 101 | [小宇宙](https://www.xiaoyuzhoufm.com/podcast/6013f37a8e2f7ee375cf40e0) | 硅谷科技人物与趋势 | ⭐⭐⭐⭐ |
| 声动早咖啡 | [sheng.fm](https://sheng.fm) | 简短商业早报 | ⭐⭐⭐ |
| 疯投圈 | [小宇宙](https://www.xiaoyuzhoufm.com/podcast/6019f1d58e2f7ee375cf462f) | 投资与消费 | ⭐⭐⭐⭐ |
| 科技早知道 | [guiguzaozhidao.com](https://guiguzaozhidao.com) | 中美科技双语视角 | ⭐⭐⭐⭐ |
| 半拿铁 | 小宇宙 / 微信公众号 | 商业故事 + 人物 | ⭐⭐⭐⭐ |
| 出海相对论 | [小宇宙](https://www.xiaoyuzhoufm.com) | 中国公司出海 | ⭐⭐⭐ |
| OnBoard! | 小宇宙 | 创投对话 | ⭐⭐⭐⭐ |
| 文化有限 | 小宇宙 / Apple | 内容产业与文化趋势 | ⭐⭐⭐ |

### 9.4 中文 / 华语 YouTube

| 频道 | 链接 | 内容特点 | 可靠度 |
|-|-|-|-|
| 影视飓风 | [youtube.com/@TimViews](https://www.youtube.com/@TimViews) | 中文头部科技/影视评测频道 | ⭐⭐⭐⭐ |
| 老石谈芯 | [youtube.com/@laoshi_tec](https://www.youtube.com/@laoshi_tec) | 半导体与芯片产业深度 | ⭐⭐⭐⭐ |
| 林亦 LYi | [youtube.com/@LYiChannel](https://www.youtube.com/@LYiChannel) | AI / LLM 科普 | ⭐⭐⭐⭐ |
| Koala 聊开源 | [youtube.com/@KoalaTech](https://www.youtube.com/@KoalaTech) | 开源 & AI 工具 | ⭐⭐⭐ |
| MoneyXYZ | [youtube.com/@MoneyXYZ](https://www.youtube.com/@MoneyXYZ) | 投资 + 商业 | ⭐⭐⭐ |

---

## 十、播客专题（音频向）

### 10.1 综合科技 / AI

| 播客 | 平台 | 内容特点 | 可靠度 |
|-|-|-|-|
| Hard Fork (NYT) | Apple / Spotify | Kevin Roose & Casey Newton，每周科技快讯 + 深度 | ⭐⭐⭐⭐ |
| Decoder (Nilay Patel, The Verge) | Apple / Spotify | CEO 访谈 + 产品战略 | ⭐⭐⭐⭐ |
| The Vergecast | Apple / Spotify | The Verge 团队周评 | ⭐⭐⭐ |
| Wired Podcasts | Apple / Spotify | Wired 播客矩阵 | ⭐⭐⭐⭐ |
| Lex Fridman Podcast | Apple / Spotify / YouTube | 长访谈（3–5h） | ⭐⭐⭐ |
| Dwarkesh Podcast | Apple / Spotify / YouTube | AI 研究者深度访谈 | ⭐⭐⭐⭐⭐ |
| The Logan Bartlett Show | Apple / Spotify | 创投 + AI 创始人 | ⭐⭐⭐⭐ |
| Gradient Dissent (Weights & Biases) | Apple / Spotify | ML 工程实践 | ⭐⭐⭐⭐ |
| Practical AI | Apple / Spotify | AI 工程化 | ⭐⭐⭐⭐ |
| TWiML (This Week in ML) | Apple / Spotify | ML 研究与产业访谈 | ⭐⭐⭐⭐ |
| Eye on AI (Craig Smith) | Apple / Spotify | AI 业界领袖访谈 | ⭐⭐⭐ |
| BG2 Pod | [bg2pod.com](https://www.bg2pod.com) | Brad Gerstner & Bill Gurley，科技股、AI、宏观 | ⭐⭐⭐⭐ |

### 10.2 商业 / 投资

| 播客 | 平台 | 内容特点 | 可靠度 |
|-|-|-|-|
| All-In Podcast | Apple / Spotify / YouTube | 硅谷热门叙事（注意带立场） | ⭐ |
| Acquired | Apple / Spotify / YouTube | 公司史纪录片式 | ⭐⭐⭐⭐⭐ |
| Invest Like the Best (Patrick O'Shaughnessy) | Apple / Spotify | 顶级投资人与创始人访谈 | ⭐⭐⭐⭐⭐ |
| Capital Allocators (Ted Seides) | Apple / Spotify | 机构投资者访谈 | ⭐⭐⭐⭐⭐ |
| Pivot (Kara Swisher & Scott Galloway) | Apple / Spotify | 科技商业快评 | ⭐⭐⭐ |
| The Prof G Pod (Scott Galloway) | Apple / Spotify | 商业评论 | ⭐⭐⭐ |
| Odd Lots (Bloomberg) | Apple / Spotify | 金融与产业深度 | ⭐⭐⭐⭐⭐ |
| Planet Money / The Indicator (NPR) | Apple / Spotify | 经济学科普 | ⭐⭐⭐⭐⭐ |
| a16z Podcast | Apple / Spotify | 投资与趋势 | ⭐⭐⭐⭐ |
| Lenny's Podcast | Apple / Spotify / YouTube | PM 与增长方法论 | ⭐⭐⭐⭐ |
| My First Million | Apple / Spotify / YouTube | 创业 Idea | ⭐⭐⭐ |
| No Priors | Apple / Spotify / YouTube | Sarah Guo & Elad Gil，AI 投资访谈 | ⭐⭐⭐⭐ |

---

## 附录 A：分层阅读策略

| 层级 | 频率 | 来源 | 目的 |
|-|-|-|-|
| L1 快讯扫描 | 每日 5–10 min | HN / Techmeme / Bloomberg Tech / TLDR AI / Reuters / Axios | 知道"发生了什么" |
| L2 行业跟踪 | 每日 15–20 min | Import AI / Bensbites / The Information / Stratechery / Platformer | 知道"为什么重要" |
| L3 深度阅读 | 每周 1–2h | Stratechery / The Diff / The Economist / MIT Tech Review / AI Snake Oil | 建立"认知框架" |
| L4 研究报告 | 每月 1–2 份 | Stanford HAI / State of AI / McKinsey / a16z / CB Insights | 更新"大图景" |

## 附录 B：工具链与防过载原则

**工具链建议**：RSS 聚合用 Feedly / Inoreader（搭配 RSSHub）；稍后读 + 高亮用 Readwise Reader；Newsletter 用单独邮箱或 Kill the Newsletter 转 RSS；播客用 Pocket Casts / Overcast / 小宇宙；X 用 List 而非主时间线；笔记沉淀到 Notion / Obsidian。

**防信息过载五原则**：① **先减后加**，先退订再加回；② **用 List 不用关注**；③ **批处理 > 实时**，周报 > 日报 > 推送；④ **季度审计订阅列表**；⑤ 连续 4 周没让你"学到新东西"或"改变想法"的信源 → 退订。

## 附录 C：信息源发现渠道

- Hacker News 首页常年是最好的"信源推荐引擎"
- X / Reddit 上的 "Who do you follow for X?" 类帖子
- Substack / Pocket / Readwise Reader 的推荐与 Feed Discovery
- 每年 State of AI / AI Index 报告引用的来源
- [AllTop](https://alltop.com) 分类聚合首页
- "Best Newsletters" / "Best Podcasts" 年度榜单

---

> **声明**：本清单基于截至 2026 年 5 月的公开可用信息源整理；可靠度评分为编辑视角的相对参考，不构成绝对标准。链接、运营状态、内容风格均可能随时间变化，建议每季度审查更新；带立场标注的信息源建议与其他来源交叉验证。
