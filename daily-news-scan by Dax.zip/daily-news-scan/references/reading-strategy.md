# 分层阅读策略与防过载原则

## 一、L1-L4 分层阅读策略

| 层级 | 频率 | 目的 | 代表信源 |
|---|---|---|---|
| **L1 快讯扫描** | 每日 5–10 min | 知道"发生了什么" | Hacker News, Techmeme, Bloomberg Tech, TLDR AI, Reuters, Axios |
| **L2 行业跟踪** | 每日 15–20 min | 知道"为什么重要" | Import AI, Bensbites, The Information, Stratechery, Platformer, 晚点 |
| **L3 深度阅读** | 每周 1–2h | 建立"认知框架" | Stratechery, The Diff, The Economist, MIT Tech Review, AI Snake Oil, SemiAnalysis |
| **L4 研究报告** | 每月 1–2 份 | 更新"大图景" | Stanford HAI, State of AI, McKinsey, a16z, CB Insights, Epoch AI |

## 二、信源角色标签（图例）

| 标签 | 含义 |
|---|---|
| ⚡ | 快讯型，时效优先 |
| 📊 | 深度分析 / 长报道 |
| 🔭 | 趋势观察 / 行业评论 |
| 💰 | 商业 / 投融资 / 财经 |
| 📚 | 学术 / 研究 / 论文 |
| 🎙 | 播客 / 音频 |

## 三、可靠度评分规则（⭐1–5）

| 评分 | 标准 |
|---|---|
| ⭐⭐⭐⭐⭐ (5 分) | 通讯社级 / 顶级期刊 / 权威研究机构（Reuters, Bloomberg, FT, MIT Tech Review, Stanford HAI 等）|
| ⭐⭐⭐⭐ (4 分) | 公认深度优质媒体或作者（Stratechery, Platformer, The Diff, Asianometry 等）|
| ⭐⭐⭐ (3 分) | 主流可靠媒体或活跃创作者（TechCrunch, The Verge, 36 氪等）|
| ⭐⭐ (2 分) | 聚合站 / 社区 / 快讯型，需结合多源（Hacker News, Engadget, Bensbites 等）|
| ⭐ (1 分) | 信噪比一般、立场较强或质量分散（All-In, Pomp Letter, Elon Musk 等）|

## 四、扫描时的优先级建议

### 默认每日扫描（L1+L2，约 25 分钟）

**必扫（⭐⭐⭐⭐⭐ 通讯社/权威）**：
- Techmeme（聚合首页）
- Bloomberg Technology
- Reuters Technology
- The Information（如有订阅）
- Import AI（周一）
- Stratechery（工作日）
- 晚点 LatePost（中文）
- 财新（中文）

**选扫（⭐⭐⭐⭐ 深度）**：
- Platformer / Casey Newton
- Semafor Tech
- 404 Media
- The Batch / Last Week in AI
- SemiAnalysis（半导体相关）
- Asianometry（产业链）

**辅助（⭐⭐⭐ 快讯/聚合）**：
- TLDR AI / Bensbites（AI 快讯摘要）
- Hacker News（社区情绪）
- Axios Tech（要点式）

### 周深度扫描（追加 L3，约 2 小时）

- The Economist Science & Tech
- MIT Tech Review
- The Diff (Byrne Hobart)
- AI Snake Oil
- Interconnects (Nathan Lambert)
- Benedict Evans Newsletter
- Acquired（公司史播客）
- Dwarkesh Podcast（AI 研究者访谈）

### 月研究报告（L4）

- Stanford HAI - AI Index Report（年度）
- State of AI Report（年度）
- McKinsey Global Institute
- CB Insights 行业地图
- Epoch AI 算力/成本追踪
- a16z / Sequoia / Greylock 趋势文章

## 五、防信息过载五原则

1. **先减后加**：先退订所有，再按需加回
2. **用 List 不用关注**：X / Twitter 用 List 分组（AI Researchers / VC / Reporters / Macro / Founders），避免主时间线噪音
3. **批处理 > 实时**：周报 > 日报 > 推送通知
4. **季度审计订阅列表**：每季度检查信源活跃度与质量
5. **学到新东西原则**：连续 4 周没让你"学到新东西"或"改变想法"的信源 → 退订

## 六、Agent 扫描时的去噪规则

执行每日扫描时，Agent 应自动剔除以下内容：

- ❌ 营销稿（"震惊！""重磅！"标题党）
- ❌ 招聘信息 / 公司 PR 通稿
- ❌ 单纯产品发布（除非 ⭐⭐⭐⭐⭐ 信源头条）
- ❌ 加密货币 pump-and-dump 类
- ❌ 与 scope 无关的政治娱乐
- ❌ 重复 24h 内已抓取过的同一事件

保留并加权：

- ✅ 多源交叉验证的事件（≥3 个 ⭐⭐⭐⭐+ 信源）
- ✅ 独家深度报道（⭐⭐⭐⭐⭐ 单点）
- ✅ 学术论文 / 权威机构报告
- ✅ 政策 / 监管动向
- ✅ 头部公司高管/创始人公开发言（来自其官方账号或权威媒体引用）

## 七、付费墙信源处理

以下信源默认有付费墙，抓取时若返回登录页：
- The Information / Stratechery / The Diff / Net Interest / FT / WSJ / Bloomberg / The Economist / Barron's / Gartner / Forrester

**处理方式**：
1. 记录为 `🔒 需订阅`
2. 保留标题（若 RSS 摘要可见）和链接
3. 不要尝试绕过付费墙
4. 在简报中标注，让用户自行选择是否订阅
