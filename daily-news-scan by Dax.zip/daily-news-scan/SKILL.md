---
name: daily-news-scan
description: 全球科技/AI/商业资讯每日扫描与简报生成。基于经评分的可信信息源清单（涵盖综合科技媒体、AI 垂直媒体、商业财经、研究机构、社区论坛、Newsletter、播客、YouTube、X 博主、中文媒体等十大类），按"L1 快讯→L2 行业→L3 深度→L4 研究"的分层阅读策略扫描信源，最终产出包含"全球关键热门资讯 / 潜在信号 / 原始信源链接"的结构化每日简报。USE WHEN 用户提及"每日扫描 / 资讯简报 / 全球科技/AI 资讯 / daily brief / news digest / 信息源扫描 / 行业动态汇总"等场景。
---

# Daily News Scan — 全球科技/AI/商业资讯每日扫描

> 用途：按可信信源清单做每日资讯扫描，输出一份**结构化简报**（热门资讯 + 潜在信号 + 原始信源）。
> 信源依据：`references/sources.md`（按可靠度 ⭐1–5 评分整理，共 200+ 条）。

---

## 1. 何时触发

用户提出以下任一意图：

- "做一份今天/本周的全球 AI/科技/商业资讯简报"
- "扫描一下今天有什么值得关注的科技新闻"
- "帮我看看 AI 行业最新动态"
- "daily brief / news digest / 信息扫描"
- 任何"基于多个信源汇总+提炼"的资讯类需求

---

## 2. 输入参数（用户可指定，缺省即用默认）

| 参数 | 默认值 | 说明 |
|---|---|---|
| `scope` | `ai+tech+business` | 主题范围：`ai` / `tech` / `business` / `ai+tech` / `ai+tech+business` |
| `time_window` | `24h` | 时间窗：`24h` / `48h` / `7d` |
| `depth` | `L1+L2+L5` | 阅读层级：`L1`(快讯) / `L1+L2`(行业默认) / `L1+L2+L3`(含深度) / `L1+L2+L5`(含观点，每周报告默认) / `all`(全量) |
| `region` | `global` | 区域偏好：`global` / `cn` / `us` / `apac` |
| `min_reliability` | `3` | 信源最低可靠度（⭐ 数），高于等于该值才纳入 |
| `output` | `markdown` | 输出格式：`markdown` / `feishu_doc`（飞书文档） |
| `top_n` | `10` | 热门资讯条数 |

执行前若用户未指定，直接使用默认值，无需追问。

---

## 3. 工作流（5 步）

### Step 1 — 加载信源清单
- Read `references/sources.md`，按 `scope` 和 `min_reliability` 过滤候选信源
- 优先级排序：可靠度 ⭐ 数 → 更新频率（每日多更 > 每日 > 周更）→ 角色匹配度（⚡ 快讯 / 📊 深度 / 🔭 趋势 / 💰 商业 / 📚 学术 / 🎙 播客）

### Step 2 — 分层抓取（并行)
按 `depth` 配置并行抓取，遵循"宽度→深度"原则：

| 层级 | 信源类型 | 抓取方式 |
|---|---|---|
| **L1 快讯层** | Techmeme / Hacker News / Reuters Tech / Bloomberg Tech / Axios Tech / TLDR AI / Bensbites | `mcp__proxy___mira__web_builtin_fetch` 拉首页 → 提取头条标题+链接 |
| **L2 行业层** | The Information / Stratechery / Platformer / Import AI / The Batch / Semafor Tech / 晚点 / 财新 | 拉最新文章列表 → 提取标题+摘要 |
| **L3 深度层** | MIT Tech Review / The Economist / The Diff / AI Snake Oil / SemiAnalysis / Asianometry | 拉最近 24-48h 内长文 |
| **L4 研究层** | Stanford HAI / State of AI / arXiv cs.CL/LG/AI / Hugging Face Papers | 仅在 depth=all 时调用 |
| **L5 观点层** | 知名人士的播客访谈 / Newsletter / 博客 / X(Twitter) 长帖（Lex Fridman / Dwarkesh / No Priors / Acquired / Invest Like the Best / Stratechery / The Diff / Import AI / Karpathy / Hinton / Hassabis / Altman / Dario Amodei / Jack Clark / Ben Thompson / Benedict Evans / 黄仁勋 / 王坚 / 张一鸣 / 王慧文 / 李彦宏 等） | 拉最近 7 天发布/更新的访谈或长文 → 提取核心观点（事实判断、趋势预测、争议立场） |

**抓取约束**：
- 单次任务总抓取数 ≤ 20 个 URL，避免超时
- 优先 ⭐⭐⭐⭐⭐ 信源，每个 ≤ 1 个 URL
- 失败的 URL 跳过，不重试 3 次以上
- 付费墙信源（The Information / Stratechery / FT 等）若返回登录页，记录为"需订阅"并保留标题

### Step 3 — 去重 + 聚类
- 按主题聚合同一事件的多源报道（如"OpenAI 发布 GPT-X"在 5 家媒体出现 → 合并为 1 条，列出所有信源）
- 去除营销稿、广告、招聘信息
- 标注"独家"（仅 1-2 个高可靠度信源报道）

### Step 4 — 信号提炼
按以下维度分类筛选：

| 类别 | 筛选标准 |
|---|---|
| **🔥 全球关键热门** | ≥ 3 个 ⭐⭐⭐⭐ 以上信源同时报道；或 ⭐⭐⭐⭐⭐ 信源头条 |
| **👀 潜在信号** | 单点独家但来自 ⭐⭐⭐⭐⭐ 信源；或多源弱信号交叉（如多个 ⭐⭐⭐ 提到同一公司/技术）；或学术/政策预兆类 |
| **🌏 区域要闻** | 按 `region` 参数补充本地视角（cn 必含晚点/财新/36氪；us 必含 WSJ/NYT/Bloomberg；apac 必含 Nikkei/SCMP） |
| **🛠 工程/工具** | 开发者/AI 工程相关新工具、新模型、benchmark |
| **💬 观点（Opinions）** | 知名人士在本周播客访谈 / Newsletter / 博客 / X 长帖中提出的核心观点。来源必须是**有明确署名的真实人物**（创始人 / CEO / 顶级研究员 / 资深行业评论员 / 头部 VC / 政策制定者等）。每条须包含：① 人物 + 身份；② 观点出处（节目名 / 媒体 + 链接）；③ 原话或精炼复述（≤ 80 字）；④ 类别标签（`事实判断` / `趋势预测` / `争议立场` / `战略路线` 之一）；⑤ 反方或交叉佐证（可选） |

每条须附 1-3 个原始信源链接，标注可靠度 ⭐。

### Step 5 — 输出简报
按 §4 模板组装；若 `output=feishu_doc`，调用 `lark-doc` skill 生成飞书文档。

---

## 4. 简报输出模板

````markdown
# 全球科技/AI/商业资讯每日简报 — YYYY-MM-DD

> 扫描范围：{scope} ｜ 时间窗：{time_window} ｜ 信源数：{N} ｜ 阅读层级：{depth}

## 🔥 全球关键热门（Top {top_n}）

### 1. {标题}
- **要点**：{1-2 句概括，事实+影响}
- **信源**：[媒体A ⭐⭐⭐⭐⭐](url1) ｜ [媒体B ⭐⭐⭐⭐](url2)
- **背景**：{可选，1 句话上下文}

### 2. ...

## 👀 潜在信号（需关注但未爆发）

- **{主题}**：{现象 + 为何值得关注} — [信源 ⭐⭐⭐⭐⭐](url)
- ...

## 🌏 区域要闻

### 中国 / 亚太
- ...

### 美国 / 欧洲
- ...

## 🛠 工程 / 工具 / 模型新动态

- {新模型/工具/benchmark + 链接}

## 💬 观点（Opinions）

> 收集本周（time_window 范围内）知名人士在播客访谈、Newsletter、博客或 X 长帖中提出的代表性观点；优先选择立场清晰、信息密度高、与本周热门事件互相印证或形成对照的发言。

### {人物姓名} ｜ {身份/公司} ｜ {类别标签}
- **观点**：{≤ 80 字的精炼复述或带引号的原话}
- **出处**：[{节目/媒体名} — {主题}](url) ｜ {发布日期}
- **背景**：{可选，1 句话补充情境/反方观点}

### {人物 2} ｜ ...

## 📚 深度阅读推荐（L3）
- [文章标题](url) — {作者/媒体}，{1 句价值描述}

## 📅 信源覆盖统计

| 类别 | 抓取数 | 成功 | 付费墙 |
|---|---|---|---|
| 综合科技 | x | x | x |
| AI 垂直 | x | x | x |
| 商业财经 | x | x | x |
| 研究/智库 | x | x | x |

> 本简报基于可信信源清单 v1.0 自动生成；可靠度评分仅供参考，建议交叉验证。
````

---

## 5. 关键执行规则

1. **并行抓取**：Step 2 中所有 fetch 调用必须在单轮 tool calls 内并行发出，禁止串行
2. **不编造**：任何条目必须有真实可访问的 URL；抓取失败的内容不得凭记忆补全；**观点板块严禁虚构人物或杜撰原话**，找不到合规观点时此板块可置空并注明"本周未抓取到符合标准的观点条目"
3. **可靠度透明**：每条都要带 ⭐ 评分
4. **去 SEO 化**：摘要直接给事实，不要"重磅！震惊！"风格
5. **付费墙处理**：标记为"🔒 需订阅"但保留标题与链接，不删除
6. **失败容忍**：单次抓取失败 ≤ 5 个可接受，> 5 个则缩减信源重试一次后继续
7. **中文输出**：默认中文；信源标题保留原文（英文不译）
8. **观点优先级**：观点板块优先选择 ⭐⭐⭐⭐+ 信源（如 Dwarkesh / Acquired / Stratechery / Import AI / Bloomberg Odd Lots / 晚点 / Lex Fridman 等）的本周新发布内容；同一人物本周出现多条观点时只保留信息密度最高的 1 条

---

## 6. References

- `references/sources.md` — 完整信源清单（按 10 大类组织，含可靠度评分、角色标签、更新频率）
- `references/reading-strategy.md` — 分层阅读策略 L1-L4 详解 + 防过载原则

## 7. 与其他 Skill 协作

| 需求 | 切换到 |
|---|---|
| 简报输出为飞书文档 | `lark-doc` |
| 简报推送到飞书群 | `im-chat-manager` / `lark-im` |
| 简报存到飞书多维表归档 | `lark-base` |
| 定时每日生成 | `mira-scheduler` |
| 简报附带可视化图表 | `consulting-charts`（外部） |
